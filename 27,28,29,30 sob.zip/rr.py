print("for")
